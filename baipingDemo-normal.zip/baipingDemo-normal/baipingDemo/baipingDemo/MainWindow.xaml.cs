﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace baipingDemo
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Topmost = true;
            this.BorderBrush = Brushes.Red;
        }

        private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
           this.Close();
        }

        private void ChangeSize(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Maximized;
        }

        private void maxSize(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Normal;
            double screenWidth = System.Windows.SystemParameters.PrimaryScreenWidth;
            double screenHeight = System.Windows.SystemParameters.PrimaryScreenHeight;
            this.Width = 1900;
            this.Height = 1020;
            this.Left = (screenWidth - this.Width)/2;
            this.Top = (screenHeight - this.Height)/2;
        }
    }
}
